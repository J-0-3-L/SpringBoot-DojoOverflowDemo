package com.joel.dojo_overflow.repositories;

import com.joel.dojo_overflow.models.Question;

public interface QuestionRepository extends BaseRepository<Question>{
}
