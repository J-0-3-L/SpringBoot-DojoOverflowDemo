package com.joel.dojo_overflow.repositories;

import com.joel.dojo_overflow.models.Tag;

public interface TagRepository extends BaseRepository<Tag>{
}
