package com.joel.dojo_overflow.repositories;

import com.joel.dojo_overflow.models.Answer;

public interface AnswerRepository extends BaseRepository<Answer>{
    
}
